var form = document.getElementById("redirect_form");
form.submit();