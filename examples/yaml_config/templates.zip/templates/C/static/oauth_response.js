/**
 * Copyright contributors to the IBM Verify Identity Access OIDC Provider Resources project
 */
var form = document.getElementById("redirect_form");
form.submit();